//
// Copyright © Essential Developer. All rights reserved.
//

public struct ResourceLoadingViewModel {
	public let isLoading: Bool
}
