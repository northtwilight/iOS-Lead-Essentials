//	
// Copyright © Essential Developer. All rights reserved.
//

import Foundation

public protocol ResourceErrorView {
	func display(_ viewModel: ResourceErrorViewModel)
}
